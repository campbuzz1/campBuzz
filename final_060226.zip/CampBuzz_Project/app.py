from flask import Flask, render_template, render_template_string, request, redirect, url_for, session, flash
import sqlite3
import hashlib
from datetime import datetime, timedelta
from functools import wraps
import os
from dotenv import load_dotenv  # <--- Import this
from flask_wtf.csrf import CSRFProtect
load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY')
csrf = CSRFProtect(app) # This protects every POST route automatically



# --- DATABASE CONNECTION ---
def get_db_connection():
    conn = sqlite3.connect('events.db')
    conn.row_factory = sqlite3.Row
    return conn

# --- UTILS ---
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash("Please login to access the Admin Panel.", "error")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# --- ROUTES ---

@app.route('/')
def home():
    conn = get_db_connection()
    # Fetch only Approved events, sorted by nearest date first
    events = conn.execute('SELECT * FROM events WHERE status = "approved" ORDER BY date ASC').fetchall()
    conn.close()
    
    # Render the new HTML file from the 'templates' folder
    return render_template('index.html', events=events)

# --- ADMIN ROUTES (Using Simple Internal Templates) ---
# We keep the Admin Panel simple for now, separate from the fancy user UI

ADMIN_TEMPLATE = """
<!doctype html>
<html>
<head>
    <title>CampBuzz Admin</title>
    <style>
        body { font-family: sans-serif; padding: 20px; max-width: 800px; margin: auto; background: #f4f4f4; }
        .card { background: white; padding: 20px; margin-bottom: 15px; border-radius: 8px; border: 1px solid #ddd; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .btn { padding: 8px 12px; text-decoration: none; color: white; border-radius: 4px; border: none; cursor: pointer; font-size: 14px; }
        .green { background: #28a745; } .red { background: #dc3545; } .blue { background: #007bff; } .grey { background: #6c757d; }
        .flash { padding: 15px; background: #ffeeba; border-left: 5px solid #ffc107; margin-bottom: 20px; }
        
        /* Form Styles */
        input, textarea { width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        label { font-weight: bold; display: block; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>⚙️ CampBuzz Admin</h1>
    <nav>
        <a href="/">← Back to Home</a> | 
        {% if session.get('logged_in') %}
            <a href="/admin">Dashboard</a> | <a href="/logout">Logout</a>
        {% endif %}
    </nav>
    <hr>
    
    {% with messages = get_flashed_messages() %}
        {% if messages %}<div class="flash">{{ messages[0] }}</div>{% endif %}
    {% endwith %}

    {% if page == 'login' %}
        <div class="card" style="max-width: 400px; margin: auto;">
            <h2>Admin Login</h2>
            <form method="post">
                <input type="hidden" name="csrf_token" value="{{ csrf_token() }}"/>
                <label>Username</label>
                <input type="text" name="username" required>
                <label>Password</label>
                <input type="password" name="password" required>
                <button class="btn blue" style="width: 100%;">Login</button>
            </form>
        </div>

    {% elif page == 'edit' %}
        <div class="card">
            <h2>✏️ Edit Event</h2>
            <form method="post">
                <input type="hidden" name="csrf_token" value="{{ csrf_token() }}"/>
                <label>Event Title</label>
                <input type="text" name="title" value="{{ event['title'] }}" required>
                
                <label>Date (YYYY-MM-DD)</label>
                <input type="text" name="date" value="{{ event['date'] }}" required placeholder="2026-05-20">
                
                <label>Organizer (Read-only)</label>
                <input type="text" value="{{ event['organizer'] }}" readonly style="background: #e9ecef;">
                
                <label>Description</label>
                <textarea name="description" rows="6" required>{{ event['description'] }}</textarea>
                
                <div style="margin-top: 10px;">
                    <button type="submit" class="btn green">💾 Save Changes</button>
                    <a href="/admin" class="btn grey">Cancel</a>
                </div>
            </form>
        </div>

    {% else %}
        <h2>Manage Events</h2>
        {% for event in events %}
            <div class="card" style="border-left: 5px solid {% if event['status']=='pending' %}orange{% else %}green{% endif %}">
                <div style="display: flex; justify-content: space-between;">
                    <h3 style="margin: 0;">{{ event['title'] }}</h3>
                    <small style="color: #666;">{{ event['date'] }}</small>
                </div>
                <p style="color: #555; font-size: 0.9em;">By: <b>{{ event['organizer'] }}</b></p>
                <p>{{ event['description'] }}</p>
                
                <div style="margin-top: 15px;">
                    {% if event['status'] == 'pending' %}
                    <form action="/approve/{{ event['id'] }}" method="post" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="{{ csrf_token() }}"/>
                        <button class="btn green">✅ Approve</button>
                    </form>
                    {% endif %}
                    
                    <a href="/edit/{{ event['id'] }}" class="btn blue">✏️ Edit</a>
                    
                    <form action="/delete/{{ event['id'] }}" method="post" style="display:inline; float: right;">
                        <input type="hidden" name="csrf_token" value="{{ csrf_token() }}"/>
                        <button class="btn red" onclick="return confirm('Delete this event?')">🗑️ Delete</button>
                    </form>
                </div>
            </div>
        {% else %}
            <p>No events found.</p>
        {% endfor %}
    {% endif %}
</body>
</html>
"""

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Load credentials from .env
        env_user = os.getenv('ADMIN_USER')
        env_pass = os.getenv('ADMIN_PASS')
        
        # Check against Environment Variables
        if username == env_user and password == env_pass:
            session['logged_in'] = True
            flash("Welcome back, Admin!", "success")
            return redirect(url_for('admin_panel'))
        else:
            flash('Invalid username or password!', 'error')
            # If login fails, we MUST return the template again
            return render_template_string(ADMIN_TEMPLATE, page='login', events=[])
    
    # This covers the 'GET' request (initial page load)
    return render_template_string(ADMIN_TEMPLATE, page='login', events=[])

@app.route('/admin')
@login_required
def admin_panel():
    conn = get_db_connection()
    events = conn.execute('SELECT * FROM events ORDER BY status DESC, date ASC').fetchall()
    conn.close()
    return render_template_string(ADMIN_TEMPLATE, page='dashboard', events=events)

@app.route('/approve/<int:event_id>', methods=['POST'])
@login_required
def approve_event(event_id):
    conn = get_db_connection()
    conn.execute('UPDATE events SET status = "approved" WHERE id = ?', (event_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))

@app.route('/delete/<int:event_id>', methods=['POST'])
@login_required
def delete_event(event_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM events WHERE id = ?', (event_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

# --- EDIT FEATURE (Simplified for brevity) ---
# --- REAL EDIT FUNCTION ---
@app.route('/edit/<int:event_id>', methods=['GET', 'POST'])
@login_required
def edit_event(event_id):
    conn = get_db_connection()
    
    # 1. HANDLE SAVING (POST Request)
    if request.method == 'POST':
        title = request.form['title']
        date_input = request.form['date']
        desc = request.form['description']

        # Validate Date Format (Important so Auto-Delete doesn't break)
        try:
            datetime.strptime(date_input, '%Y-%m-%d')
        except ValueError:
            flash("⚠️ Error: Date must be YYYY-MM-DD (e.g., 2026-02-25)")
            # Reload form with bad data so user can fix it
            event = conn.execute('SELECT * FROM events WHERE id = ?', (event_id,)).fetchone()
            conn.close()
            return render_template_string(ADMIN_TEMPLATE, page='edit', event=event)

        # Update Database
        conn.execute('UPDATE events SET title = ?, date = ?, description = ? WHERE id = ?', 
                     (title, date_input, desc, event_id))
        conn.commit()
        conn.close()
        
        flash("✅ Event updated successfully!")
        return redirect(url_for('admin_panel'))

    # 2. HANDLE SHOWING FORM (GET Request)
    else:
        event = conn.execute('SELECT * FROM events WHERE id = ?', (event_id,)).fetchone()
        conn.close()
        
        if not event:
            flash("Event not found.")
            return redirect(url_for('admin_panel'))
            
        # Show the 'edit' page mode
        return render_template_string(ADMIN_TEMPLATE, page='edit', event=event)

if __name__ == '__main__':
    app.run(debug=True, port=5000)