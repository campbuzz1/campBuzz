import sqlite3
import dateparser
import time
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import os
from dotenv import load_dotenv
from google import genai
import json
import os

load_dotenv()

# --- CONFIGURATION ---
BOT_TOKEN = os.getenv('BOT_TOKEN')
OWNER_ID = int(os.getenv('OWNER_ID'))
MAX_MSGS_PER_HOUR = 5
client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel('gemini-1.5-flash')

def get_db():
    return sqlite3.connect('events.db')

# --- SECURITY CHECKS ---
def check_access(user_id, username):
    """
    Returns:
    - 'allow': User is approved and within rate limit.
    - 'pending': User needs approval.
    - 'rate_limit': User sent too many messages.
    """
    conn = get_db()
    c = conn.cursor()
    
    # 1. Check if user exists
    user = c.execute("SELECT status, message_history FROM bot_users WHERE user_id = ?", (user_id,)).fetchone()
    
    current_time = int(time.time())
    
    if not user:
        # New User -> Add as Pending
        c.execute("INSERT INTO bot_users (user_id, username, status) VALUES (?, ?, 'pending')", (user_id, username))
        conn.commit()
        conn.close()
        return 'new_user'
        
    status, history_str = user
    
    if status != 'approved':
        conn.close()
        return 'pending'
    
    # 2. Rate Limiting Logic
    # Convert string "t1,t2,t3" into list of integers
    timestamps = [int(t) for t in history_str.split(',') if t]
    
    # Filter: Keep only timestamps from the last 3600 seconds (1 hour)
    valid_timestamps = [t for t in timestamps if t > (current_time - 3600)]
    
    if len(valid_timestamps) >= MAX_MSGS_PER_HOUR:
        conn.close()
        return 'rate_limit'
    
    # Add new timestamp and save
    valid_timestamps.append(current_time)
    new_history = ",".join(map(str, valid_timestamps))
    
    c.execute("UPDATE bot_users SET message_history = ? WHERE user_id = ?", (new_history, user_id))
    conn.commit()
    conn.close()
    return 'allow'

# --- HANDLERS ---

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 **Event Bot**\nSend your event details. If you are new, approval is required.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    user_input = update.message.text
    
    # ... (Keep your existing check_access security logic here) ...

    # 🧠 PROMPT (Updated for better JSON extraction)
    prompt = f"""
    Extract event details from this text: "{user_input}"
    Return ONLY a JSON object with these keys:
    - title: (String)
    - date: (String in YYYY-MM-DD format)
    - description: (Short summary)
    
    If no date is found, use "TBD".
    """

    try:
        # Use the new .models.generate_content method
        response = client.models.generate_content(
            model='gemini-1.5-flash', 
            contents=prompt
        )
        
        # The new SDK provides the text directly
        # Clean response to ensure only JSON is parsed
        clean_json = response.text.strip().lstrip('```json').rstrip('```')
        event_details = json.loads(clean_json)

        title = event_details.get('title', 'Untitled')
        date_str = event_details.get('date', 'TBD')
        desc = event_details.get('description', user_input)

        # Save to DB (Ensure you have your save_event function ready)
        save_event(title, date_str, desc, user.username or "Unknown")

        await update.message.reply_text(
            f"🤖 **AI (New SDK) Processed!**\n\n📌 **Title:** {title}\n📅 **Date:** {date_str}\n📝 **Summary:** {desc}"
        )

    except Exception as e:
        print(f"Extraction Error: {e}")
        await update.message.reply_text("❌ Failed to process with AI. Please check the logs.")
async def approve_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Only Owner can use this
    if update.message.from_user.id != OWNER_ID:
        return

    try:
        target_id = int(context.args[0])
        conn = get_db()
        conn.execute("UPDATE bot_users SET status = 'approved' WHERE user_id = ?", (target_id,))
        conn.commit()
        conn.close()
        
        await update.message.reply_text(f"✅ User {target_id} approved!")
        # Optional: Notify the user they are approved
        try:
            await context.bot.send_message(chat_id=target_id, text="🎉 **You have been approved!**\nYou can now submit events.")
        except:
            pass # User might have blocked bot
            
    except (IndexError, ValueError):
        await update.message.reply_text("❌ Usage: `/approve <user_id>`")

def save_event(title, date, description, organizer):
    conn = get_db()
    c = conn.cursor()
    c.execute("INSERT INTO events (title, date, description, organizer) VALUES (?, ?, ?, ?)",
              (title, date, description, organizer))
    conn.commit()
    conn.close()

def main():
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Owner Command
    application.add_handler(CommandHandler("approve", approve_user))
    application.add_handler(CommandHandler("start", start))
    
    # General Message Handler
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("🛡️ Secure Bot is running...")
    application.run_polling()

if __name__ == '__main__':
    main()