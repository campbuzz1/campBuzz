from flask import Flask, render_template, render_template_string, request, redirect, url_for, session, flash
import sqlite3
import hashlib
from datetime import datetime, timedelta
from functools import wraps

app = Flask(__name__)
app.secret_key = 'campbuzz_secret_key'

# --- DATABASE CONNECTION ---
def get_db_connection():
    conn = sqlite3.connect('events.db')
    conn.row_factory = sqlite3.Row
    return conn

# --- UTILS ---
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash("Please login to access the Admin Panel.", "error")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# --- ROUTES ---

@app.route('/')
def home():
    conn = get_db_connection()
    # Fetch only Approved events, sorted by nearest date first
    events = conn.execute('SELECT * FROM events WHERE status = "approved" ORDER BY date ASC').fetchall()
    conn.close()
    
    # Render the new HTML file from the 'templates' folder
    return render_template('index.html', events=events)

# --- ADMIN ROUTES (Using Simple Internal Templates) ---
# We keep the Admin Panel simple for now, separate from the fancy user UI

ADMIN_TEMPLATE = """
<!doctype html>
<html>
<head>
    <title>CampBuzz Admin</title>
    <style>
        body { font-family: sans-serif; padding: 20px; max-width: 800px; margin: auto; background: #f4f4f4; }
        .card { background: white; padding: 15px; margin-bottom: 10px; border-radius: 8px; border: 1px solid #ddd; }
        .btn { padding: 5px 10px; text-decoration: none; color: white; border-radius: 4px; border: none; cursor: pointer; }
        .green { background: #28a745; } .red { background: #dc3545; } .blue { background: #007bff; }
        .flash { padding: 10px; background: #ffeeba; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h1>⚙️ CampBuzz Admin</h1>
    <a href="/">← Back to Home</a> | <a href="/logout">Logout</a>
    <hr>
    
    {% with messages = get_flashed_messages() %}
        {% if messages %}<div class="flash">{{ messages[0] }}</div>{% endif %}
    {% endwith %}

    {% if page == 'login' %}
        <form method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button class="btn blue">Login</button>
        </form>
    {% else %}
        <h2>Pending Approvals</h2>
        {% for event in events %}
            <div class="card" style="border-left: 5px solid {% if event['status']=='pending' %}orange{% else %}green{% endif %}">
                <h3>{{ event['title'] }}</h3>
                <p><b>Date:</b> {{ event['date'] }} | <b>By:</b> {{ event['organizer'] }}</p>
                <p>{{ event['description'] }}</p>
                
                {% if event['status'] == 'pending' %}
                <form action="/approve/{{ event['id'] }}" method="post" style="display:inline;">
                    <button class="btn green">Approve</button>
                </form>
                {% endif %}
                
                <form action="/delete/{{ event['id'] }}" method="post" style="display:inline;">
                    <button class="btn red" onclick="return confirm('Delete?')">Delete</button>
                </form>
                
                <a href="/edit/{{ event['id'] }}" class="btn blue">Edit</a>
            </div>
        {% else %}
            <p>No events found.</p>
        {% endfor %}
    {% endif %}
</body>
</html>
"""

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if user and user['password_hash'] == hash_password(password):
            session['logged_in'] = True
            return redirect(url_for('admin_panel'))
        else:
            flash("Invalid credentials")
            
    return render_template_string(ADMIN_TEMPLATE, page='login', events=[])

@app.route('/admin')
@login_required
def admin_panel():
    conn = get_db_connection()
    events = conn.execute('SELECT * FROM events ORDER BY status DESC, date ASC').fetchall()
    conn.close()
    return render_template_string(ADMIN_TEMPLATE, page='dashboard', events=events)

@app.route('/approve/<int:event_id>', methods=['POST'])
@login_required
def approve_event(event_id):
    conn = get_db_connection()
    conn.execute('UPDATE events SET status = "approved" WHERE id = ?', (event_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))

@app.route('/delete/<int:event_id>', methods=['POST'])
@login_required
def delete_event(event_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM events WHERE id = ?', (event_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

# --- EDIT FEATURE (Simplified for brevity) ---
@app.route('/edit/<int:event_id>', methods=['GET', 'POST'])
@login_required
def edit_event(event_id):
    # Reuse the same logic from the previous step if you want the edit form
    # For now, this placeholder redirects back to admin
    flash("Edit feature requires the full template code from previous step.")
    return redirect(url_for('admin_panel'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)